package ATM.system;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ATM extends OptionMenu {

	public static void main(String[] args) throws Exception {

		Account a= new Account();
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/springjdbc", "root", "root");

		PreparedStatement stmt = connection.prepareStatement("insert into account values(?,?,?,?)");
		stmt.setInt(1, a.getCustomerNumber());
		stmt.setInt(2, a.getPinNumber());
		stmt.setDouble(3, a.getCheckingBalance());
		stmt.setDouble(4, a.getSavingsBalance());
		
		int i=stmt.executeUpdate();
		ResultSet resultset = stmt.executeQuery("Select * from account");

		while (resultset.next()) {
			System.out.println(resultset.getInt(1) + " " + resultset.getInt(2) + " " + resultset.getInt(3) + " "
					+ resultset.getInt(4));
		}
		connection.close();

		OptionMenu optionMenu = new OptionMenu();

		optionMenu.getLogin();
	}

}
