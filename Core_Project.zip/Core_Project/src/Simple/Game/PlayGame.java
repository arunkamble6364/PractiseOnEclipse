package Simple.Game;

public class PlayGame {

	public static void main(String[] args) {
		
		Player1 player1=new Player1("Abc", "sword", 100);
		/*
		 * System.out.println(player1.getName());
		 * System.out.println(player1.getWeapon());
		 * System.out.println(player1.getHealth());
		 * 
		 * player1.damagedByGun1(); player1.damagedByGun1(); player1.damagedByGun2();
		 */
		Player2 player2=new Player2("Sam", "machine Gun", 100, false);
		player2.damagedByGun1();
		player2.damagedByGun1();
		player2.damagedByGun2();
		/*
		 * player2.damagedByGun2(); player2.damagedByGun2();
		 */


	}

}
