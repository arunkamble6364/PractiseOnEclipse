package com.jdbc;

import java.sql.Connection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;

public class InsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// creating connection
			String url = "jdbc:mysql://localhost:3306/arun";
			String user = "root";
			String pass = "Arun1234@";
			Connection con = DriverManager.getConnection(url, user, pass);
			// creating query
			String q = "insert into employee(id,name) values(?,?)";
			PreparedStatement ps = con.prepareStatement(q);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter EmpID:");
			int id = Integer.parseInt(br.readLine());
			System.out.println("Enter name:");
			String name = br.readLine();
			// seting the values
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.executeUpdate();
			System.out.println("Inserted Successfully");
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
