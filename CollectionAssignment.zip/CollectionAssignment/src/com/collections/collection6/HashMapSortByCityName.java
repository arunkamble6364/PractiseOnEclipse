package com.collections.collection6;

import java.util.HashMap;
import java.util.TreeMap;

public class HashMapSortByCityName {
	public static void main(String[] args) {

		HashMap<String, Integer> hm = new HashMap<>();
		hm.put("Pune", 635365);
		hm.put("Kolhapur", 60545);
		hm.put("Hyderabad", 535343);
		hm.put("Banglore", 623736);
		hm.put("Mumbai", 534362);

		TreeMap<String, Integer> sort = new TreeMap<>();

		sort.putAll(hm);

		System.out.println(sort);
	}
}
