package com.arun.exception;

public class SalaryInvalidException extends Exception {

	String message;

	public SalaryInvalidException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
