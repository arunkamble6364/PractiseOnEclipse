package com.arun.form;

import org.apache.struts.action.ActionForm;

public class DeleteAndUpdateForm extends ActionForm{
	
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	
	

}
