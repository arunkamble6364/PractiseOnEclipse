package com.arun.form;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.validator.ValidatorForm;

import com.arun.DAO.EmployeeDaoimpl;

public class EmployeeForm extends ActionForm {

	private int eid;
	private String enme;
	private int deptid;
	private int salary;
	private String designtion;
	private int mgrid;
	private String password;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEnme() {
		return enme;
	}

	public void setEnme(String enme) {
		this.enme = enme;
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDesigntion() {
		return designtion;
	}

	public void setDesigntion(String designtion) {
		this.designtion = designtion;
	}

	public int getMgrid() {
		return mgrid;
	}

	public void setMgrid(int mgrid) {
		this.mgrid = mgrid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "EmployeeForm [eid=" + eid + ", enme=" + enme + ", deptid=" + deptid + ", salary=" + salary
				+ ", designtion=" + designtion + ", mgrid=" + mgrid + ", password=" + password + "]";
	}

	/*
	 * @Override public ActionErrors validate(ActionMapping mapping,
	 * HttpServletRequest request) { // TODO Auto-generated method stub
	 * 
	 * ActionErrors errors = new ActionErrors(); if (this.enme == null ||
	 * this.enme.trim().length() == 0) errors.add("enme", new
	 * ActionMessage("error.form.null", "enme"));
	 * 
	 * if (this.designtion == null || this.enme.trim().length() == 0)
	 * errors.add("designtion", new ActionMessage("error.form.null", "designtion"));
	 * 
	 * if (this.salary < 10000 || this.salary > 50000) errors.add("salary", new
	 * ActionMessage("error.range", new Object[] { "salary", "10000", "50000" }));
	 * try { if (new EmployeeDaoimpl().doesEmployeeUsernameExists(this.enme))
	 * errors.add("enme", new ActionMessage("error.exists", "enme")); } catch
	 * (Exception ex) {
	 * 
	 * }
	 * 
	 * Pattern p = Pattern.compile("^[A-Za-z]+$", Pattern.CASE_INSENSITIVE); Matcher
	 * m = p.matcher(this.enme); if (!m.find()) errors.add("enme", new
	 * ActionMessage("error.invalid.regex"));
	 * 
	 * if (!errors.isEmpty()) request.setAttribute("hasError", "true");
	 * 
	 * return errors; }
	 */
	
	
	
	
	

}
