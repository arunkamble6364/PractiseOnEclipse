package com.arun.model;

public class Employee {
	
	private int eid;
	private String enme;
	private int deptid;
	private int salary;
	private String designtion;
	private int mgrid;
	private String password;
	public Employee(int eid, String enme, int deptid, int salary, String designtion, int mgrid) {
		super();
		this.eid = eid;
		this.enme = enme;
		this.deptid = deptid;
		this.salary = salary;
		this.designtion = designtion;
		this.mgrid = mgrid;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEnme() {
		return enme;
	}
	public void setEnme(String enme) {
		this.enme = enme;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDesigntion() {
		return designtion;
	}
	public void setDesigntion(String designtion) {
		this.designtion = designtion;
	}
	public int getMgrid() {
		return mgrid;
	}
	public void setMgrid(int mgrid) {
		this.mgrid = mgrid;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", enme=" + enme + ", deptid=" + deptid + ", salary=" + salary + ", designtion="
				+ designtion + ", mgrid=" + mgrid + "]";
	}
	

}
