package com.arun.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.arun.DAO.EmployeeDaoimpl;

public class LayoutAction extends DispatchAction {

	public ActionForward body(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		request.setAttribute("employees", new EmployeeDaoimpl().getAllEmployee());
		return mapping.findForward("body");
	}

	public ActionForward mody(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		//request.setAttribute("name", "shailesh");
		return mapping.findForward("mody");
	}

}
