package com.arun.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.arun.DAO.EmployeeDaoimpl;
import com.arun.form.DeleteAndUpdateForm;

public class EmployeeDeleteAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub

		/*
		 * new
		 * EmployeeDaoimpl().deleteEmployee(Integer.parseInt(request.getParameter("id"))
		 * ); request.setAttribute("employees", new EmployeeDaoimpl().getAllEmployee());
		 * return mapping.findForward("success");
		 */

		DeleteAndUpdateForm du = (DeleteAndUpdateForm) form;
		int id = du.getId();
		new EmployeeDaoimpl().deleteEmployee(id);
		request.setAttribute("employees", new EmployeeDaoimpl().getAllEmployee());

		return mapping.findForward("success");

	}

}
