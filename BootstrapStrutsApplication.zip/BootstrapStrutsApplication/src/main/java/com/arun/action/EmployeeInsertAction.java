package com.arun.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.arun.DAO.EmployeeDaoimpl;
import com.arun.exception.SalaryInvalidException;
import com.arun.form.EmployeeForm;
import com.arun.model.Employee;

public class EmployeeInsertAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		EmployeeForm emp = (EmployeeForm) form;
		//System.out.println(10/0);
		System.out.println(emp);
		
		if(emp.getSalary()>50000)
			throw new SalaryInvalidException("the salary is invalid");
		
		Employee e1 = new Employee();
		e1.setEid(emp.getEid());
		e1.setEnme(emp.getEnme());
		e1.setDeptid(emp.getDeptid());
		e1.setSalary(emp.getSalary());
		e1.setDesigntion(emp.getDesigntion());
		e1.setMgrid(emp.getMgrid());
		new EmployeeDaoimpl().addEmployee(e1);
		request.setAttribute("employees", new EmployeeDaoimpl().getAllEmployee());
		return mapping.findForward("success");
		
	}

	
	
	
}
