package com.array;

public class PythagorousTemplate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 3, b = 4, c = 5;

		if (a * a + b * b == c * c) {
			System.out.println(" pythagorus theorem satisfy");
		} else {
			System.out.println("pythagoras theorem not satisfy");
		}

	}

}
