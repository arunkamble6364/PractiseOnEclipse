package com.oops.Question8;

public class Laptop extends Electronic {
	public Laptop(String id, String semiconductorType, String dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}

}
