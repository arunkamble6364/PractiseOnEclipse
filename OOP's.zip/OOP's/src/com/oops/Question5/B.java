package com.oops.Question5;

public class B extends A {
	@Override
	void sub(int a, int b) {
		int sub = a - b;
		System.out.println(sub);
	}
}
