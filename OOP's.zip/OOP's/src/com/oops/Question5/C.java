
package com.oops.Question5;

public class C extends B {
	@Override
	void mul(int a, int b) {
		int mul = a * b;
		System.out.println(mul);
	}

}
