package com.exceptions.exception4;

import java.util.Scanner;

public class ItemPurchase extends Exception {
	public ItemPurchase(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
