package com.exceptions.exception8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordException extends Exception {

	public PasswordException(String message) {
		super(message);

	}

}
