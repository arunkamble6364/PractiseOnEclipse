package com.exceptions.exception9;

public class CollerStandardDeviate  extends Exception {
	public CollerStandardDeviate(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
