package com.exceptions.exception10;

public class Test {
	public static void main(String[] args) {

		int arr[] = { 2, 4, 7, 9, 5, 6, 34 };
		Parent p = new Child();
		p.maximum(arr);
	}
}
