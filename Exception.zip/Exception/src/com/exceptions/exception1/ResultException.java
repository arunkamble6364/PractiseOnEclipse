package com.exceptions.exception1;

public class ResultException extends RuntimeException {
	public ResultException(String msg)
	{
		super(msg);
	}

}
