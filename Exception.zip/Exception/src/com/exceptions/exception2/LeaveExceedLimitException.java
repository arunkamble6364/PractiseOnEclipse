package com.exceptions.exception2;

public class LeaveExceedLimitException extends Exception {
	 public LeaveExceedLimitException(String message) {
	        super(message);
	        // TODO Auto-generated constructor stub
	    }

	
}
