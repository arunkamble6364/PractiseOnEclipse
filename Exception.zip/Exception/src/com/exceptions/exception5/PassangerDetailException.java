package com.exceptions.exception5;

public class PassangerDetailException extends Exception {

	   public PassangerDetailException(String message) {
	        super(message);
	        
	    }
}
