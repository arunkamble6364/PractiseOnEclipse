package com.exception;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  try 
          {
              System.out.print("Yash" + " " + 1 / 0);
          }
          catch(ArithmeticException e) 
          {
      	System.out.print("Technology");        	
          }
      }

	}


