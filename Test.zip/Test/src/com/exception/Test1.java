package com.exception;

class Laptop {
	public void start() {
		try {
			System.out.print("Starting up ");
			throw new Exception();
		} catch (Exception e) {
			System.out.print("Problem ");
			System.exit(0);
		} finally {
			System.out.print("Shutting down ");
		}
	}

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  new Laptop().start();
	}

}
