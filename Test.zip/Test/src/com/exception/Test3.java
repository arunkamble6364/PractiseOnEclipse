package com.exception;

class Base extends Exception {
	
	
}
class Derived extends Base {
	
	
}

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  try 
        {
              throw new Derived();
        }catch(Base b) 
        {
              System.out.println("Caught base class exception");
        }catch(Derived d) 
        {
              System.out.println("Caught derived class exception");
        }
		

	}

}
