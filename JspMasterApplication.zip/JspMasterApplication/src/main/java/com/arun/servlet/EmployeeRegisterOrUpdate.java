package com.arun.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.arun.dao.EmployeeDaoimpl;
import com.arun.model.Employee;

/**
 * Servlet implementation class EmployeeRegisterOrUpdate
 */
@WebServlet("/EmployeeRegisterOrUpdate")
public class EmployeeRegisterOrUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeRegisterOrUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		int id = Integer.parseInt(request.getParameter("eid"));
		int salary = Integer.parseInt(request.getParameter("salary"));
		int deptid = Integer.parseInt(request.getParameter("deptid"));
		int mgrid = Integer.parseInt(request.getParameter("mgrid"));
		String enme = request.getParameter("enme");
		String designtion = request.getParameter("designtion");
		Employee employee = new Employee(id, enme, deptid, salary, designtion, mgrid);
		boolean exists = false;
		try {
			
			exists = new EmployeeDaoimpl().doesEmployeeExists(Integer.parseInt(request.getParameter(designtion)));
		}catch(Exception ex) {
			
		}
		if(exists) {
			try {
				
			}catch (Exception ex) {
				
			}
			response.getWriter().print("<h4>Employee Sucessfully updated</h4>");
		}else {
		
		try {
			new EmployeeDaoimpl().updateEmployee(employee);
			
		}catch(Exception ex) {
			
		}
		response.getWriter().print("<h4>Employee Sucessfully added</h4>");
		}
		request.getRequestDispatcher("EmployeeDisplayServlet").include(request, response);
		
	}

}
