package com.arun.dao;

import java.sql.SQLException;
import com.arun.model.*;
import java.util.List;



public interface EmployeeDAO  {
	public List<Employee> getAllEmployee() throws SQLException;
	public Employee getAllEmployeeById(int id) throws SQLException;
	public void addEmployee(Employee employee) throws SQLException;
	
	public void updateEmployee(Employee employee) throws SQLException;
	public void deleteEmployee(int id) throws SQLException;
	
}
