package com.arun.dao;

import java.sql.Connection;
import com.arun.Connection.*;
import com.arun.model.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.arun.dao.*;



public class EmployeeDaoimpl  implements EmployeeDAO  {

	@Override
	public List<Employee> getAllEmployee() throws SQLException{

		List<Employee> employees=new ArrayList<Employee>();
		Connection conn=ConnectionMaster.getConnection();
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery("Select * from employee");
		while(rs.next()) {
			employees.add(new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6)));
		}
		
		
		conn.close();
		return employees;
	}

	@Override
	public Employee getAllEmployeeById(int id) throws SQLException {
		Employee employee=null;
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement pst=conn.prepareStatement("Select * from employee where eid=?");
		pst.setInt(1, id);
		ResultSet rs=pst.executeQuery();
		rs.next();
		employee=new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6));
		
		return employee;
	}

	@Override
	public void addEmployee(Employee employee) throws SQLException {
		String sql="insert into employee(eid,enme,deptid,salary,designation,mgrid)values(?,?,?,?,?,?)";
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,employee.getEid());
		pst.setString(2, employee.getEnme());
		pst.setInt(3, employee.getDeptid());
		pst.setInt(4, employee.getSalary());
		pst.setString(5, employee.getDesigntion());
		pst.setInt(6, employee.getMgrid());
		pst.executeUpdate();
		conn.close();
		
		
	}

	@Override
	public void updateEmployee(Employee employee) throws SQLException {

		String sql="update employee set enme=?, deptid=?,salary=?,designtion=?,mgrid=? where eid=?";
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(6,employee.getEid());
		pst.setString(1, employee.getEnme());
		pst.setInt(2, employee.getDeptid());
		pst.setInt(3, employee.getSalary());
		pst.setString(4, employee.getDesigntion());
		pst.setInt(5, employee.getMgrid());
		pst.executeUpdate();
		conn.close();

		
	}

	@Override
	public void deleteEmployee(int id) throws SQLException {
		String sql  = "delete from employee where eid=?";
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1, id);
		pst.executeUpdate();
		conn.close();
		
		
	}

	public boolean doesEmployeeExists(int id) throws SQLException {

		String sql = "select * from employee where eid =?";
		Connection conn = ConnectionMaster.getConnection();
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setInt(1, id);
		ResultSet rs = pst.executeQuery();
		return rs.next()?true:false;
		
		
	}

	

}
