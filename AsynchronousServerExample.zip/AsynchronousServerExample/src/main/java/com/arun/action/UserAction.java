package com.arun.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.arun.model.Employee;
import com.arun.DAO.EmployeeDaoimpl;

public class UserAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		
		List<Employee> p=new EmployeeDaoimpl().getAllEmployee();
		System.out.print(p);
		request.setAttribute("emp",p);
		
		return mapping.findForward("success");
	}

	
	
}
