package com.arun.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionMaster {

	public static Connection getConnection() {
		
		Connection conn =null;
		try {
			String url="jdbc:mysql://localhost:3306/smaster";
			String username="root";
			String password="Arun1234@";
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url,username,password);
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}
}
