package com.arun.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.arun.DAO.EmployeeDaoimpl;
import com.arun.model.Employee;

public class EmployeeDataTag extends TagSupport {

	private String enme;

	public void setEnme(String enme) {
		this.enme = enme;
	}

	@Override
	public int doStartTag() throws JspException {

		JspWriter out = pageContext.getOut();
		try {

			Employee e1 = new EmployeeDaoimpl().getemployeebyname(this.enme);

		} catch (Exception ex) {
		}

		return EVAL_PAGE;

	}

}
