package com.arun.tags;

import java.util.Calendar;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class DateTagMaster extends TagSupport {

	@Override
	public int doStartTag() throws JspException {

		JspWriter out = pageContext.getOut();
		try {
			out.print(Calendar.getInstance().getTime());

		} catch (Exception ex) {}
		
		return EVAL_PAGE;

	}

}
