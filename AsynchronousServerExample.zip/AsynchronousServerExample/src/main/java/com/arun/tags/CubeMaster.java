package com.arun.tags;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class CubeMaster extends TagSupport {

	private int number;

	public void setNumber(int number) {
		this.number = number;
	}

	@Override
	public int doStartTag() throws JspException {

		JspWriter out = pageContext.getOut();
		try {
			out.print(this.number*this.number*this.number);

		} catch (IOException ex) {
		}

		return EVAL_PAGE;

	}

}
