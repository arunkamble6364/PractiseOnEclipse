package com.arun.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AjaxServlet
 */
@WebServlet("/AjaxServlet")
public class AjaxServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Map<String, Integer> m1 = new HashMap<String, Integer>();

	public AjaxServlet() {

		m1.put("nikhil", 35);
		m1.put("atul", 23);
		m1.put("samir", 42);
		m1.put("kishor", 38);

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		// System.out.println("the server has been called");
		String name = request.getParameter("n1");
		// System.out.println("the name is " + name);

		// int age = (Integer) m1.get(name);
		
		if (m1.keySet().stream().filter(e -> e.equals(name)).collect(Collectors.toList()).size() == 1)

			out.write("you are " + m1.get(name) + " years of age");
		else
			out.write("the name does not exists");

		/*
		 * if(m1.equals(name)) { int age = (Integer) m1.get(name); out.write("You are  "
		 * + age + " years of age "); }else { out.write("User does not exist"); }
		 */

		/*
		 * int age = m1.get(name); out.write("you are " + age + " years of age");
		 */

	}

}
