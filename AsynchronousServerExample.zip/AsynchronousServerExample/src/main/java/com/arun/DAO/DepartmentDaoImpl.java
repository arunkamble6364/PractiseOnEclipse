package com.arun.DAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.arun.connection.ConnectionMaster;
import com.arun.model.*;
import java.sql.Connection;

public class DepartmentDaoImpl implements DepartmentDao {

	@Override
	public int getDeptIdFromDname(String dname) throws SQLException {

		Connection conn = ConnectionMaster.getConnection();
		PreparedStatement pst = conn.prepareStatement("select deptid from department where dname=?");
		pst.setString(1, dname);

		ResultSet rs = pst.executeQuery();
		rs.next();

		return rs.getInt(1);

	}

	@Override
	public List<Department> getallDepartment() throws SQLException {
		Connection conn = ConnectionMaster.getConnection();
		List<Department> d = new ArrayList();
		PreparedStatement prep = conn.prepareStatement("Select * from department");
		ResultSet rs = prep.executeQuery();
		while (rs.next()) {
			d.add(new Department(rs.getInt(1), rs.getString(2)));
		}
		conn.close();
		return d;

	}

}
