package com.arun.DAO;

import java.sql.SQLException;
import java.util.List;

import com.arun.model.*;

public interface EmployeeDAO  {
	public List<Employee> getAllEmployee() throws SQLException;
	public Employee getAllEmployeeById(int id) throws SQLException;
	public void addEmployee(Employee employee) throws SQLException;
	
	public void updateEmployee(Employee employee) throws SQLException;
	public void deleteEmployee(int id) throws SQLException;
	
	public boolean isEmployeeLoginValid(String username, String password) throws SQLException;
	public boolean doesEmployeeUsernameExists(String username) throws SQLException;
	
	
}
