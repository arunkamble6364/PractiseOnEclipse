package com.arun.DAO;

import java.sql.SQLException;
import com.arun.model.*;
import java.util.List;



public interface DepartmentDao {
	
	public int getDeptIdFromDname(String dname) throws SQLException;
	public List<Department> getallDepartment() throws SQLException;
 
}
