package main.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@RequestMapping("/home")
	public String get(Model model) {
		
		System.out.println("This is home controller");
		model.addAttribute("id", 1);
		model.addAttribute("name", "Akshay");
		
		List<String> names= new ArrayList<String>();
		names.add("Sanket");
		names.add("Pranav");
		names.add("Lavish");
		names.add("Shubham");
		names.add("Parvez");
		model.addAttribute("n", names);
		
		
		return "first";
	}
	
	
	@RequestMapping("/help")
	public ModelAndView help() {
		System.out.println("This is help controller");
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("name", "Suraj Kamat");
		modelAndView.addObject("rollnumber", 12);
		
		modelAndView.setViewName("help");
		
		return modelAndView;
	}
	
	
	
}
